const products = [
    {
        "id": 1,
        "name":"漆器彩绘针刻圆盘",
        "price": 188,
        "image": "images/1.jpg",
        "description": "定制曾楚漆器彩绘针刻圆盘，中国漆器曾侯乙仿古高档手工艺品定制"
    },
    {
        "id": 2,
        "name":"黄鹤楼漆盘",
        "price": 198,
        "image": "images/2.jpg",
        "description": "中国漆器湖北武汉纪念品工艺品定制摆件"
    },
    {
        "id": 3,
        "name":"漆器手工盒",
        "price": 298,
        "image": "images/3.jpg",
        "description": "中国漆器湖北随州曾侯乙桃木檀木高端手工定制"
    },
    {
        "id": 4,
        "name":"曾侯乙鸳鸯盒",
        "price": 498,
        "image": "images/4.jpg",
        "description": "中国漆器高档手工礼品定制外事收藏"
    },
    {
        "id": 5,
        "name":"桃木梳子",
        "price": 315,
        "image": "images/5.jpg",
        "description": "中国漆器仿古湖北随州曾侯乙大漆生漆定制"
    },
    {
        "id": 6,
        "name":"仿古鱼耳杯",
        "price": 213,
        "image": "images/6.jpg",
        "description": "中国漆器随州曾侯乙高档手工品定制摆件"
    },
    {
        "id": 7,
        "name":"彩绘龙凤漆盘",
        "price": 525,
        "image": "images/7.jpg",
        "description": "中国漆器高档手工艺品随州定制仿古"
    },
    {
        "id": 8,
        "name":"龙凤呈祥餐具套装",
        "price": 556,
        "image": "images/8.jpg",
        "description": "中国漆器湖北随州曾侯乙高档礼品"
    }
];
export default products;